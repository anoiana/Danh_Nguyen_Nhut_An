Video demo: https://youtu.be/5K1359uF65k
----------------------------------------------------------------------------
Tài khoản có sẵn trong hệ thống:

- Tài khoản 1:
username: khangho150@gmail.com
mật khẩu: 123456

- Tài khoản 2:
username: thanhngan10604@gmail.com
mật khẩu: ngan12345
----------------------------------------------------------------------------
SDK tối thiểu là 24
SDK nhắm tới là 34
JDK của dự án là Java 8
Link realtime database: https://console.firebase.google.com/u/0/project/android-final-46c47/overview
Nhóm đã add email của thầy (vudinhhong@tdtu.edu.vn) để xem đường link trên.
----------------------------------------------------------------------------
Tính năng nâng cao: Trong tính năng gõ từ, nhóm em có cài đặt một tính năng đề xuất từ nếu người dùng không trả lời được bằng cách nhấn vào chữ "Hint" khi đang làm bài. Tính năng này chỉ được sử dung 3 lần trong một lần làm bài ở mỗi từ vựng để đảm bảo rằng người dùng có thể học tốt các từ vựng khi làm kiểm tra.